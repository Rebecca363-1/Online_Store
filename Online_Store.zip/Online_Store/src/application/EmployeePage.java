package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.sql.*;

public class EmployeePage {

    @FXML private TextField item_idTF, item_nameTF, item_priceTF, quantityTF;

    @FXML private TableView<Item> employeeTable;
    @FXML private TableColumn<Item, Integer> item_id;
    @FXML private TableColumn<Item, String> item_name;
    @FXML private TableColumn<Item, Double> item_price;
    @FXML private TableColumn<Item, Integer> quantity_in_stock;

    @FXML private TableView<Customer> customer_table;
    @FXML private TableColumn<Customer, Integer> customer_id;
    @FXML private TableColumn<Customer, String> customer_name;
    @FXML private TableColumn<Customer, String> customer_username;
    @FXML private TableColumn<Customer, String> customer_password;
    @FXML private TableColumn<Customer, String> address;

    @FXML private TableView<Order> order_table;
    @FXML private TableColumn<Order, Integer> order_id;
    @FXML private TableColumn<Order, Integer> customer_id_order;
    @FXML private TableColumn<Order, Integer> item_id_order;
    @FXML private TableColumn<Order, String> shipping_address;
    @FXML private TableColumn<Order, String> status;

    private ObservableList<Item> data = FXCollections.observableArrayList();
    private ObservableList<Customer> customers = FXCollections.observableArrayList();
    private ObservableList<Order> orders = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Initialize item table
        item_id.setCellValueFactory(cellData -> cellData.getValue().itemIdProperty().asObject());
        item_name.setCellValueFactory(cellData -> cellData.getValue().itemNameProperty());
        item_price.setCellValueFactory(cellData -> cellData.getValue().itemPriceProperty().asObject());
        quantity_in_stock.setCellValueFactory(cellData -> cellData.getValue().quantityProperty().asObject());
        employeeTable.setItems(data);

        // Initialize customer table
        customer_id.setCellValueFactory(cellData -> cellData.getValue().customerIdProperty().asObject());
        customer_name.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
        customer_username.setCellValueFactory(cellData -> cellData.getValue().usernameProperty());
        customer_password.setCellValueFactory(cellData -> cellData.getValue().passwordProperty());
        address.setCellValueFactory(cellData -> cellData.getValue().addressProperty());
        customer_table.setItems(customers);

        // Initialize order table
        order_id.setCellValueFactory(cellData -> cellData.getValue().orderIdProperty().asObject());
        customer_id_order.setCellValueFactory(cellData -> cellData.getValue().customerIdProperty().asObject());
        item_id_order.setCellValueFactory(cellData -> cellData.getValue().itemIdProperty().asObject());
        shipping_address.setCellValueFactory(cellData -> cellData.getValue().shippingAddressProperty());
        status.setCellValueFactory(cellData -> cellData.getValue().statusProperty());
        order_table.setItems(orders);

        // Load data
        loadItems();
        loadCustomers();

        // Show items by default
        showItemsTable();
    }

    @FXML
    public void handleAddItem(ActionEvent event) {
        showItemsTable();
        try {
            int id = Integer.parseInt(item_idTF.getText());
            String name = item_nameTF.getText();
            double price = Double.parseDouble(item_priceTF.getText());
            int quantity = Integer.parseInt(quantityTF.getText());

            Item newItem = new Item(id, name, price, quantity);
            data.add(newItem);

            try (Connection connection = Databaseconnection.getConnection()) {
                String sql = "INSERT INTO Items (item_id, item_name, item_price, quantity_in_stock) VALUES (?, ?, ?, ?)";
                PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setInt(1, id);
                stmt.setString(2, name);
                stmt.setDouble(3, price);
                stmt.setInt(4, quantity);
                stmt.executeUpdate();
            }

            item_idTF.clear();
            item_nameTF.clear();
            item_priceTF.clear();
            quantityTF.clear();

        } catch (NumberFormatException e) {
            showAlert("Please enter valid numeric values for ID, Price, and Quantity.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database error: " + e.getMessage());
        }

        loadItems();
    }

    @FXML
    public void handleShowCustomers(ActionEvent event) {
        employeeTable.setVisible(false);
        customer_table.setVisible(true);
        order_table.setVisible(false);

        item_idTF.setVisible(false);
        item_nameTF.setVisible(false);
        item_priceTF.setVisible(false);
        quantityTF.setVisible(false);
    }

    @FXML
    public void handleOrders(ActionEvent event) {
        showOrdersTable();
        loadOrders();
    }

    private void showItemsTable() {
        employeeTable.setVisible(true);
        customer_table.setVisible(false);
        order_table.setVisible(false);

        item_idTF.setVisible(true);
        item_nameTF.setVisible(true);
        item_priceTF.setVisible(true);
        quantityTF.setVisible(true);
    }

    private void showOrdersTable() {
        employeeTable.setVisible(false);
        customer_table.setVisible(false);
        order_table.setVisible(true);

        item_idTF.setVisible(false);
        item_nameTF.setVisible(false);
        item_priceTF.setVisible(false);
        quantityTF.setVisible(false);
    }

    private void loadCustomers() {
        customers.clear();
        try (Connection connection = Databaseconnection.getConnection()) {
            String sql = "SELECT * FROM Customers";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Customer customer = new Customer(
                        rs.getInt("customer_id"),
                        rs.getString("customer_name"),
                        rs.getString("customer_username"),
                        rs.getString("customer_password"),
                        rs.getString("address")
                );
                customers.add(customer);
            }
        } catch (SQLException e) {
            showAlert("Error loading customer data: " + e.getMessage());
        }
    }

    private void loadItems() {
        data.clear();
        try (Connection connection = Databaseconnection.getConnection()) {
            String sql = "SELECT * FROM Items";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Item item = new Item(
                        rs.getInt("item_id"),
                        rs.getString("item_name"),
                        rs.getDouble("item_price"),
                        rs.getInt("quantity_in_stock")
                );
                data.add(item);
            }
        } catch (SQLException e) {
            showAlert("Error loading item data: " + e.getMessage());
        }
    }

    private void loadOrders() {
        orders.clear();
        try (Connection connection = Databaseconnection.getConnection()) {
            String sql = "SELECT * FROM Orders";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Order order = new Order(
                        rs.getInt("order_id"),
                        rs.getInt("customer_id"),
                        rs.getInt("item_id"),
                        rs.getString("shipping_address"),
                        rs.getString("status")
                );
                orders.add(order);
            }
        } catch (SQLException e) {
            showAlert("Error loading order data: " + e.getMessage());
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Input Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

