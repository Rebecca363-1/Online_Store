package application;

import javafx.beans.property.*;

public class Order {
    private final IntegerProperty orderId;
    private final IntegerProperty customerId;
    private final IntegerProperty itemId;
    private final StringProperty shippingAddress;
    private final StringProperty status;

    public Order(int orderId, int customerId, int itemId, String shippingAddress, String status) {
        this.orderId = new SimpleIntegerProperty(orderId);
        this.customerId = new SimpleIntegerProperty(customerId);
        this.itemId = new SimpleIntegerProperty(itemId);
        this.shippingAddress = new SimpleStringProperty(shippingAddress);
        this.status = new SimpleStringProperty(status);
    }

    public int getOrderId() {
        return orderId.get();
    }

    public IntegerProperty orderIdProperty() {
        return orderId;
    }

    public int getCustomerId() {
        return customerId.get();
    }

    public IntegerProperty customerIdProperty() {
        return customerId;
    }

    public int getItemId() {
        return itemId.get();
    }

    public IntegerProperty itemIdProperty() {
        return itemId;
    }

    public String getShippingAddress() {
        return shippingAddress.get();
    }

    public StringProperty shippingAddressProperty() {
        return shippingAddress;
    }

    public String getStatus() {
        return status.get();
    }

    public StringProperty statusProperty() {
        return status;
    }
}
