package application;

import javafx.beans.property.*;

public class Item {
    private final IntegerProperty itemId;
    private final StringProperty itemName;
    private final DoubleProperty itemPrice;
    private final IntegerProperty quantity;

    public Item(int itemId, String itemName, double itemPrice, int quantity) {
        this.itemId = new SimpleIntegerProperty(itemId);
        this.itemName = new SimpleStringProperty(itemName);
        this.itemPrice = new SimpleDoubleProperty(itemPrice);
        this.quantity = new SimpleIntegerProperty(quantity);
    }

    public int getItemId() { return itemId.get(); }
    public String getItemName() { return itemName.get(); }
    public double getItemPrice() { return itemPrice.get(); }
    public int getQuantity() { return quantity.get(); }

    public IntegerProperty itemIdProperty() { return itemId; }
    public StringProperty itemNameProperty() { return itemName; }
    public DoubleProperty itemPriceProperty() { return itemPrice; }
    public IntegerProperty quantityProperty() { return quantity; }
}
